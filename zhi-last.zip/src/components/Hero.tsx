import { motion, AnimatePresence } from 'motion/react';
import { useTranslation } from 'react-i18next';
import { useState, useEffect } from 'react';

const bannerImages = [
  "https://images.unsplash.com/photo-1447933601403-0c6688de566e?q=80&w=1920&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1497935586351-b67a49e012bf?q=80&w=1920&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1509042239860-f550ce710b93?q=80&w=1920&auto=format&fit=crop",
];

export default function Hero() {
  const { t } = useTranslation();
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prevIndex) => (prevIndex + 1) % bannerImages.length);
    }, 5000); // Change image every 5 seconds
    
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative w-full min-h-[90vh] flex items-center overflow-hidden">
      {/* Background Banner Image Slider */}
      <AnimatePresence mode="popLayout">
        <motion.img 
          key={currentImageIndex}
          src={bannerImages[currentImageIndex]}
          alt={`ZHI Coffee Banner ${currentImageIndex + 1}`}
          initial={{ opacity: 0, scale: 1.05 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.5 }}
          className="absolute inset-0 w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
      </AnimatePresence>
      
      {/* Overlays for dark moody feeling and text readability */}
      <div className="absolute inset-0 bg-black/50 z-[1]"></div>
      <div className="absolute inset-0 bg-coffee-dark/40 mix-blend-multiply z-[1]"></div>

      <div className="container mx-auto px-8 relative z-10 grid grid-cols-1 gap-12 items-center pt-24 pb-12">
        
        {/* Left Content */}
        <motion.div 
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="text-white space-y-6 max-w-3xl"
        >
          <span className="text-sm font-sans tracking-[0.2em] text-white/70 uppercase">
            {t('hero.subtitle')}
          </span>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-serif leading-[1.1]">
            {t('hero.title1')} <br />
            <span className="italic text-white font-serif">{t('hero.title2')}</span>
          </h1>
          
          <div className="pt-8">
            <button className="px-8 py-3 rounded-full border border-white hover:bg-white hover:text-coffee-dark transition-all duration-300 font-sans text-sm tracking-wider uppercase font-bold">
              {t('hero.explore')}
            </button>
          </div>
        </motion.div>

      </div>
    </section>
  );
}
