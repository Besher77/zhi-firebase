import { Facebook, Twitter, Instagram, DiscIcon as Pinterest } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';

export default function Footer() {
  const { t } = useTranslation();

  return (
    <>
      <section className="bg-coffee-light py-20 relative text-center">
        <div className="absolute top-0 start-0 w-full -translate-y-[98%] z-20 pointer-events-none">
           <svg viewBox="0 0 1440 80" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-20 text-coffee-light rtl:scale-x-[-1]" preserveAspectRatio="none">
              <path d="M0,80 C120,60 240,80 360,60 C480,40 600,70 720,50 C840,30 960,60 1080,40 C1200,20 1320,50 1440,30 L1440,80 L0,80 Z" fill="currentColor"></path>
           </svg>
        </div>

        <div className="container mx-auto px-4 max-w-2xl">
          <h2 className="text-4xl font-serif text-coffee-dark mb-4 tracking-wide">{t('footer.subscribe')}</h2>
          <p className="text-coffee-muted mb-8 italic font-serif">
            {t('footer.subDesc')}
          </p>
          
          <form className="flex flex-col sm:flex-row max-w-xl mx-auto gap-4 sm:gap-0" onSubmit={e => e.preventDefault()}>
             <input 
               type="email" 
               placeholder={t('footer.placeholder')} 
               className="flex-1 bg-transparent border-b border-t border-s sm:border-e-0 border-coffee-muted/30 px-6 py-4 outline-none font-sans text-xs tracking-widest placeholder:text-coffee-muted focus:border-coffee-dark transition-colors rounded-full sm:rounded-e-none text-start"
             />
             <button className="bg-coffee-dark text-white px-10 py-4 rounded-full sm:rounded-s-none font-sans text-xs font-bold tracking-widest hover:bg-brand transition-colors">
               {t('footer.btn')}
             </button>
          </form>
        </div>

        <div className="absolute bottom-0 start-0 w-full translate-y-[98%] z-20 pointer-events-none rotate-180">
           <svg viewBox="0 0 1440 80" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-20 text-coffee-light rtl:scale-x-[-1]" preserveAspectRatio="none">
              <path d="M0,80 C120,60 240,80 360,60 C480,40 600,70 720,50 C840,30 960,60 1080,40 C1200,20 1320,50 1440,30 L1440,80 L0,80 Z" fill="currentColor"></path>
           </svg>
        </div>
      </section>

      <footer className="bg-coffee-dark pt-32 pb-16 text-white/80">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
            
            <div className="md:col-span-2">
              <Link to="/" className="font-serif text-4xl font-bold tracking-wider italic text-white mb-6 block">
                ZHI Coffee
              </Link>
              <p className="text-white/60 text-sm leading-relaxed mb-6 max-w-sm text-justify">
                {t('footer.desc')}
              </p>
              <div className="flex space-x-4 rtl:space-x-reverse mt-6">
                <a href="#" className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center hover:bg-brand hover:border-brand transition-colors text-white"><Facebook className="w-4 h-4" /></a>
                <a href="#" className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center hover:bg-brand hover:border-brand transition-colors text-white"><Twitter className="w-4 h-4" /></a>
                <a href="#" className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center hover:bg-brand hover:border-brand transition-colors text-white"><Pinterest className="w-4 h-4" /></a>
                <a href="#" className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center hover:bg-brand hover:border-brand transition-colors text-white"><Instagram className="w-4 h-4" /></a>
              </div>
            </div>

            <div>
              <h4 className="font-sans text-sm font-bold uppercase tracking-widest text-white mb-6">{t('footer.orders')}</h4>
              <ul className="space-y-4 text-sm text-white/60">
                <li><Link to="/help" className="hover:text-brand transition-colors">Help and advice</Link></li>
                <li><Link to="/shipping" className="hover:text-brand transition-colors">Shipping & Returns</Link></li>
                <li><Link to="/terms" className="hover:text-brand transition-colors">Terms and conditions</Link></li>
                <li><Link to="/refund" className="hover:text-brand transition-colors">Refund Policy</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-sans text-sm font-bold uppercase tracking-widest text-white mb-6">{t('footer.myacct')}</h4>
              <ul className="space-y-4 text-sm text-white/60">
                <li><a href="#" className="hover:text-brand transition-colors">Login</a></li>
                <li><a href="#" className="hover:text-brand transition-colors">Register Account</a></li>
                <li><a href="#" className="hover:text-brand transition-colors">My Wishlist</a></li>
                <li><a href="#" className="hover:text-brand transition-colors">My Compare</a></li>
              </ul>
            </div>

          </div>

          <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center text-xs text-white/50">
             <p>{t('footer.rights')}</p>
             <div className="flex space-x-4 rtl:space-x-reverse mt-4 md:mt-0">
               <img src="https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg" alt="PayPal" className="h-4 opacity-50 grayscale" referrerPolicy="no-referrer" />
               <img src="https://upload.wikimedia.org/wikipedia/commons/a/a4/Mastercard_2019_logo.svg" alt="Mastercard" className="h-4 opacity-50 grayscale" referrerPolicy="no-referrer" />
               <img src="https://upload.wikimedia.org/wikipedia/commons/0/04/Visa.svg" alt="Visa" className="h-4 opacity-50 grayscale" referrerPolicy="no-referrer" />
             </div>
          </div>
        </div>
      </footer>
    </>
  );
}
