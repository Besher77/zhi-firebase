import { motion, AnimatePresence } from 'motion/react';
import { Star, ShoppingBag, Zap, Check, X, Heart, ChevronLeft, ChevronRight } from 'lucide-react';
import { useState, useEffect } from 'react';
import { useCart } from '../context/CartContext';
import React from 'react';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../context/AuthContext';
import { doc, getDoc, setDoc, deleteDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';

export interface ProductCardProps {
  key?: React.Key;
  product: {
    id: number | string;
    name: string;
    price: string | number;
    oldPrice?: string | number;
    discount?: string;
    image: string;
    images?: string[];
    desc?: string;
    features?: string[];
  };
  index: number;
}

export default function ProductCard({ product, index }: ProductCardProps) {
  const { addToCart } = useCart();
  const { user, openModal: openAuthModal } = useAuth();
  const { t, i18n } = useTranslation();
  const isAr = i18n.language === 'ar';
  
  const [addedItem, setAddedItem] = useState<boolean>(false);
  const [isModalOpen, setModalOpen] = useState(false);
  const [isWishlisted, setIsWishlisted] = useState<boolean>(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const imagesList = product.images && product.images.length > 0 ? product.images : [product.image];

  useEffect(() => {
    const checkWishlist = async () => {
      if (user) {
        try {
          const docRef = doc(db, 'users', user.uid, 'favorites', product.id.toString());
          const docSnap = await getDoc(docRef);
          if (docSnap.exists()) {
            setIsWishlisted(true);
          } else {
            setIsWishlisted(false);
          }
        } catch (error) {
          console.error("Error checking wishlist: ", error);
        }
      } else {
        setIsWishlisted(false);
      }
    };
    checkWishlist();
  }, [user, product.id]);

  const handleAddToCart = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    addToCart({
      id: product.id.toString(),
      name: product.name,
      price: typeof product.price === 'string' ? parseFloat(product.price) : product.price,
      image: product.image
    }, 1);
    
    setAddedItem(true);
    setTimeout(() => setAddedItem(false), 2000);
  };

  const toggleWishlist = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!user) {
      openAuthModal('signIn');
      return;
    }
    
    const newStatus = !isWishlisted;
    setIsWishlisted(newStatus); // Optimistic UI update

    try {
      const docRef = doc(db, 'users', user.uid, 'favorites', product.id.toString());
      if (newStatus) {
        await setDoc(docRef, { productId: product.id, addedAt: new Date().toISOString() });
      } else {
        await deleteDoc(docRef);
      }
    } catch (error) {
      console.error("Error updating wishlist: ", error);
      setIsWishlisted(!newStatus); // Revert on failure
    }
  };

  const nextImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentImageIndex((prev) => (prev + 1) % imagesList.length);
  };

  const prevImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentImageIndex((prev) => (prev - 1 + imagesList.length) % imagesList.length);
  };

  return (
    <>
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ delay: index * 0.1 }}
        className="group flex flex-col bg-white rounded-2xl p-4 shadow-sm hover:shadow-md transition-shadow duration-300 relative"
      >
        {/* Discount Badge */}
        {product.discount && (
          <div className="absolute top-4 start-4 bg-[#ccff00] text-coffee-dark text-[10px] font-bold px-2.5 py-1 flex items-center rounded-full z-10">
            <Zap className="w-3 h-3 me-1 fill-current rtl:scale-x-[-1]" /> {product.discount}
          </div>
        )}
        
        {/* Wishlist Button */}
        <button 
          onClick={toggleWishlist}
          className={`absolute top-4 end-4 z-10 transition-colors ${
            isWishlisted ? 'text-red-500' : 'text-gray-300 hover:text-red-400'
          }`}
        >
          <Heart className="w-5 h-5 fill-current" />
        </button>

        {/* Product Image area */}
        <div 
          onClick={() => setModalOpen(true)}
          className="relative h-56 mb-4 mt-8 flex justify-center items-center cursor-pointer overflow-hidden"
        >
          <AnimatePresence>
            {addedItem && (
              <motion.div 
                className="absolute inset-0 bg-white/60 backdrop-blur-sm z-10 rounded-xl flex flex-col items-center justify-center text-brand font-bold"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="bg-brand text-white p-3 rounded-full mb-2 shadow-lg"
                >
                   <Check className="w-6 h-6" />
                </motion.div>
                <span className="text-sm font-sans tracking-wide uppercase">{isAr ? 'تمت الإضافة' : 'Added'}</span>
              </motion.div>
            )}
          </AnimatePresence>
          <img 
            src={product.image} 
            alt={product.name} 
            className="h-full object-contain mix-blend-multiply group-hover:scale-110 transition-transform duration-500" 
            referrerPolicy="no-referrer" 
          />
        </div>
        
        {/* Product Details */}
        <div className="flex flex-col flex-1 mt-auto">
          {/* Stars */}
          <div className="flex text-gray-300 mb-3">
            {[...Array(5)].map((_, i) => <Star key={i} className="w-3.5 h-3.5 fill-current" />)}
            <span className="text-gray-400 text-[10px] ms-1.5">(0)</span>
          </div>
          
          {/* Title */}
          <h3 
            className="font-serif text-[17px] font-bold text-coffee-dark mb-4 cursor-pointer hover:text-brand transition-colors"
            onClick={() => setModalOpen(true)}
          >
            {product.name}
          </h3>
          
          {/* Footer Row: Price & Cart */}
          <div className="flex justify-between items-center mt-auto">
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <span className="font-sans font-bold text-sm text-coffee-dark">{product.price} {isAr ? 'رس' : 'SAR'}</span>
              {product.oldPrice && (
                <span className="relative font-sans text-xs text-gray-400">
                  {product.oldPrice} {isAr ? 'رس' : 'SAR'}
                  <span className="absolute top-1/2 start-0 w-full h-[1.5px] bg-red-400/80 -translate-y-1/2"></span>
                </span>
              )}
            </div>
            
            <button 
              onClick={handleAddToCart}
              disabled={addedItem}
              className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center hover:bg-gray-200 text-coffee-dark transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <ShoppingBag className="w-4 h-4" />
            </button>
          </div>
        </div>
      </motion.div>

      {/* Product Details Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => { setModalOpen(false); setCurrentImageIndex(0); }}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-4xl bg-white rounded-2xl shadow-2xl overflow-hidden z-10 flex flex-col md:flex-row max-h-[90vh]"
              dir={isAr ? 'rtl' : 'ltr'}
            >
              <button 
                onClick={() => { setModalOpen(false); setCurrentImageIndex(0); }}
                className="absolute top-4 end-4 w-8 h-8 bg-black/10 text-coffee-dark rounded-full flex items-center justify-center hover:bg-black/20 transition-colors z-20"
              >
                <X className="w-4 h-4" />
              </button>
              
              <div className="w-full md:w-1/2 p-8 bg-coffee-light flex items-center justify-center min-h-[300px] md:min-h-0 relative">
                {imagesList.length > 1 && (
                  <>
                    <button 
                      onClick={prevImage}
                      className="absolute start-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/80 rounded-full shadow-md flex items-center justify-center hover:bg-white text-coffee-dark z-10 transition-colors"
                    >
                      <ChevronLeft className={`w-5 h-5 ${isAr ? 'rotate-180' : ''}`} />
                    </button>
                    <button 
                      onClick={nextImage}
                      className="absolute end-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/80 rounded-full shadow-md flex items-center justify-center hover:bg-white text-coffee-dark z-10 transition-colors"
                    >
                      <ChevronRight className={`w-5 h-5 ${isAr ? 'rotate-180' : ''}`} />
                    </button>
                  </>
                )}
                <img src={imagesList[currentImageIndex]} alt={product.name} className="w-full max-h-[400px] object-contain mix-blend-multiply transition-opacity duration-300" referrerPolicy="no-referrer" />
                
                {/* Dots */}
                {imagesList.length > 1 && (
                  <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-1.5">
                    {imagesList.map((_, i) => (
                      <div 
                        key={i} 
                        className={`w-2 h-2 rounded-full transition-all ${i === currentImageIndex ? 'bg-coffee-dark w-4' : 'bg-coffee-dark/30'}`}
                      />
                    ))}
                  </div>
                )}
              </div>
              
              <div className="w-full md:w-1/2 p-8 md:p-12 flex flex-col justify-center overflow-y-auto">
                 <div className="flex text-brand mb-4">
                   {[...Array(5)].map((_, i) => <Star key={i} className="w-5 h-5 fill-current" />)}
                 </div>
                 <h2 className="text-3xl md:text-4xl font-serif font-bold text-coffee-dark mb-4 leading-tight">{product.name}</h2>
                 <div className="flex items-center space-x-4 rtl:space-x-reverse mb-8 pt-4 border-t border-border-light">
                   <span className="font-sans text-3xl font-bold text-coffee-dark">{product.price} {isAr ? 'رس' : 'SAR'}</span>
                   {product.oldPrice && <span className="font-sans text-xl text-coffee-muted line-through">{product.oldPrice} {isAr ? 'رس' : 'SAR'}</span>}
                 </div>
                 
                 <div className="text-coffee-muted text-sm leading-relaxed mb-8 space-y-4">
                   {product.desc ? (
                     <p>{product.desc}</p>
                   ) : (
                     <p className="italic">{isAr ? 'لا يوجد وصف متاح لهذا المنتج.' : 'No description available for this product.'}</p>
                   )}
                   
                   {product.features && product.features.length > 0 && (
                     <ul className="list-disc list-inside space-y-1 font-serif text-coffee-dark pt-2">
                       {product.features.map((feature, i) => (
                         <li key={i}>{feature}</li>
                       ))}
                     </ul>
                   )}
                 </div>
                 
                 <button 
                  onClick={() => { handleAddToCart(); setModalOpen(false); }}
                  className="w-full py-4 mt-auto bg-coffee-dark text-white rounded-full hover:bg-brand transition-colors flex items-center justify-center font-bold tracking-widest uppercase text-sm shadow-md"
                 >
                   <ShoppingBag className="w-4 h-4 me-2" />
                   {isAr ? 'أضف للسلة' : 'Add to Cart'}
                 </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}
