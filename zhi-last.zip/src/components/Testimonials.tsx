import { motion } from 'motion/react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useTranslation } from 'react-i18next';

export default function Testimonials() {
  const { t } = useTranslation();

  const users = [
    "https://randomuser.me/api/portraits/men/32.jpg",
    "https://randomuser.me/api/portraits/women/44.jpg",
    "https://randomuser.me/api/portraits/women/68.jpg",
    "https://randomuser.me/api/portraits/men/46.jpg",
    "https://randomuser.me/api/portraits/men/22.jpg"
  ];

  return (
    <section className="py-24 bg-white text-center border-b border-border-light/50">
      <div className="container mx-auto px-4 max-w-4xl">
        
        {/* Quote Icon */}
        <div className="text-brand flex justify-center mb-6">
           <svg width="40" height="40" viewBox="0 0 24 24" fill="currentColor" className="rtl:scale-x-[-1]"><path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z"/></svg>
        </div>

        <span className="text-xs font-sans tracking-[0.2em] text-coffee-dark uppercase mb-8 block font-semibold">{t('testimonials.tag')}</span>

        <motion.p 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-2xl md:text-3xl font-serif text-coffee-muted italic leading-relaxed mb-12"
        >
          {t('testimonials.quote')}
        </motion.p>

        {/* Avatars */}
        <div className="flex items-center justify-center space-x-6 rtl:space-x-reverse mb-8">
           <button className="w-10 h-10 rounded-full border border-border-light flex items-center justify-center text-coffee-muted hover:text-coffee-dark hover:border-coffee-dark transition-colors">
              <ChevronLeft className="w-5 h-5 rtl:hidden" />
              <ChevronRight className="w-5 h-5 hidden rtl:block" />
           </button>

           <div className="flex space-x-4 rtl:space-x-reverse items-center">
             {users.map((url, i) => {
                const isActive = i === 2; // Middle one active
                return (
                  <div key={i} className={`rounded-full overflow-hidden border-2 transition-all duration-300 ${isActive ? 'w-20 h-20 border-brand' : 'w-12 h-12 border-transparent opacity-60'}`}>
                    <img src={url} alt="User" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  </div>
                )
             })}
           </div>

           <button className="w-10 h-10 rounded-full border border-border-light flex items-center justify-center text-coffee-muted hover:text-coffee-dark hover:border-coffee-dark transition-colors">
              <ChevronRight className="w-5 h-5 rtl:hidden" />
              <ChevronLeft className="w-5 h-5 hidden rtl:block" />
           </button>
        </div>

        <p className="font-serif text-coffee-dark font-medium px-4">{t('testimonials.user')}</p>

      </div>
    </section>
  );
}
