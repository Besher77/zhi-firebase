import { motion } from 'motion/react';
import { Play } from 'lucide-react';
import { useTranslation } from 'react-i18next';

export default function VideoStory() {
  const { t } = useTranslation();

  return (
    <section className="relative py-32 flex items-center justify-center min-h-[60vh] overflow-hidden">
      {/* Background Image with Parallax illusion */}
      <div 
        className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1524350876685-274059332603?q=80&w=1920&auto=format&fit=crop')] bg-cover bg-center bg-fixed bg-no-repeat rtl:scale-x-[-1]"
        style={{ backgroundBlendMode: 'multiply', backgroundColor: 'rgba(26, 22, 21, 0.7)' }}
      ></div>

      <div className="container relative z-10 mx-auto px-4 text-center max-w-3xl text-white">
        <motion.div
           initial={{ opacity: 0, scale: 0.9 }}
           whileInView={{ opacity: 1, scale: 1 }}
           viewport={{ once: true }}
           transition={{ duration: 0.8 }}
        >
          <span className="font-serif italic text-2xl mb-4 block">{t('story.tag')}</span>
          <h2 className="text-5xl md:text-6xl font-serif mb-6 uppercase tracking-wider text-white">{t('story.title')}</h2>
          <p className="text-white/80 leading-relaxed mb-12">
            {t('story.desc')}
          </p>

          <button className="w-20 h-20 mx-auto border z-20 border-white/50 rounded-full flex items-center justify-center hover:bg-brand/80 hover:border-brand transition-all group duration-300 backdrop-blur-sm">
            <Play className="w-8 h-8 text-white fill-white ms-2 rtl:rotate-180 transition-transform group-hover:scale-110" />
          </button>
        </motion.div>
      </div>
    </section>
  );
}
