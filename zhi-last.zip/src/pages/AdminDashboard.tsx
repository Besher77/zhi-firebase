import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Navigate } from 'react-router-dom';
import { Users, ShoppingBag, BarChart3, Settings, LogOut, Menu, X, Package, Ticket, Truck } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useTranslation } from 'react-i18next';
import AdminCategories from '../components/admin/AdminCategories';
import AdminProducts from '../components/admin/AdminProducts';
import AdminCoupons from '../components/admin/AdminCoupons';
import AdminDelivery from '../components/admin/AdminDelivery';

export default function AdminDashboard() {
  const { user, loading, logout } = useAuth();
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');
  const { t, i18n } = useTranslation();
  const isAr = i18n.language === 'ar';

  useEffect(() => {
    document.documentElement.dir = i18n.language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = i18n.language;
  }, [i18n.language]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-coffee-light">
        <div className="w-10 h-10 border-4 border-brand border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  // Protected Route Logic
  if (!user || user.role !== 'admin') {
    return <Navigate to="/" replace />;
  }

  const navItems = [
    { id: 'overview', label: t('admin.overview'), icon: BarChart3 },
    { id: 'categories', label: t('nav.product') + ' Categories', icon: Package },
    { id: 'products', label: t('admin.products'), icon: Package },
    { id: 'orders', label: t('admin.orders'), icon: ShoppingBag },
    { id: 'coupons', label: isAr ? 'أكواد الخصم' : 'Coupons', icon: Ticket },
    { id: 'delivery', label: isAr ? 'الشحن والتوصيل' : 'Delivery', icon: Truck },
    { id: 'users', label: t('admin.users'), icon: Users },
    { id: 'settings', label: t('admin.settings'), icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-coffee-light flex font-sans">
      
      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSidebarOpen(false)}
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <motion.aside 
        className={`fixed inset-y-0 start-0 z-50 w-64 bg-coffee-dark text-white flex flex-col transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full rtl:translate-x-full'}`}
      >
        <div className="p-6 flex items-center justify-between border-b border-white/10">
          <h2 className="text-2xl font-serif font-bold text-brand tracking-widest">{t('admin.title')}</h2>
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden text-white/70 hover:text-white">
            <X className="w-6 h-6" />
          </button>
        </div>
        
        <div className="p-4 border-b border-white/10">
          <p className="text-sm text-white/50 mb-1">{t('admin.loggedInAs')}</p>
          <p className="font-bold">{user.name}</p>
        </div>

        <nav className="flex-1 px-4 py-6 space-y-2 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setSidebarOpen(false);
                }}
                className={`w-full flex items-center p-3 rounded-xl transition-all ${
                  isActive 
                    ? 'bg-brand text-white font-bold' 
                    : 'text-white/70 hover:bg-white/10 hover:text-white'
                }`}
              >
                <Icon className={`w-5 h-5 me-3 ${isActive ? 'text-white' : 'text-white/70'}`} />
                {item.label}
              </button>
            )
          })}
        </nav>

        <div className="p-4 mt-auto border-t border-white/10">
          <button 
            onClick={logout}
            className="w-full flex items-center p-3 text-red-400 hover:bg-red-400/10 hover:text-red-300 rounded-xl transition-all"
          >
            <LogOut className="w-5 h-5 me-3" />
            {t('admin.signOut')}
          </button>
        </div>
      </motion.aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        
        {/* Top Navbar for Mobile */}
        <header className="bg-white px-6 py-4 border-b border-border-light flex items-center justify-between sticky top-0 z-30 shadow-sm">
          <div className="flex items-center">
            <button 
              onClick={() => setSidebarOpen(true)}
              className="me-4 text-coffee-dark lg:hidden hover:text-brand"
            >
              <Menu className="w-6 h-6" />
            </button>
            <h1 className="text-xl font-bold text-coffee-dark hidden sm:block font-serif">
              {navItems.find(i => i.id === activeTab)?.label}
            </h1>
          </div>
        </header>

        {/* Dashboard Content */}
        <div className="flex-1 p-4 md:p-8 overflow-y-auto w-full">
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {/* KPI Cards */}
            {[
              { label: t('admin.kpis.users'), value: Math.floor(Math.random() * 1000) },
              { label: t('admin.kpis.orders'), value: Math.floor(Math.random() * 500) },
              { label: t('admin.kpis.revenue'), value: '14,520 SAR' },
              { label: t('admin.kpis.sessions'), value: Math.floor(Math.random() * 100) }
            ].map((kpi, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="bg-white p-6 rounded-2xl shadow-sm border border-border-light group hover:border-brand/30 transition-colors"
              >
                <h3 className="text-sm font-bold text-coffee-muted uppercase tracking-widest mb-2">{kpi.label}</h3>
                <p className="text-3xl font-serif font-bold text-brand">
                  {kpi.value}
                </p>
                <div className="mt-4 text-sm text-green-600 font-bold flex items-center">
                  +12.5% <span className="text-coffee-muted font-normal ms-1">{t('admin.kpis.fromLastMonth')}</span>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Main Area based on Tab */}
          <motion.div 
            key={activeTab}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className={`bg-white rounded-2xl shadow-sm border border-border-light ${activeTab === 'overview' ? 'p-6 min-h-[400px]' : 'p-4 md:p-8'}`}
          >
            {activeTab === 'categories' ? (
              <AdminCategories />
            ) : activeTab === 'products' ? (
              <AdminProducts />
            ) : activeTab === 'coupons' ? (
              <AdminCoupons />
            ) : activeTab === 'delivery' ? (
              <AdminDelivery />
            ) : (
              <>
                <h2 className="text-xl font-bold text-coffee-dark mb-4 border-b border-border-light pb-4 font-serif">
                  {navItems.find(i => i.id === activeTab)?.label} - {t('admin.management')}
                </h2>
                
                <div className="text-center text-coffee-muted py-20 flex flex-col items-center">
                  <Package className="w-16 h-16 mx-auto mb-4 text-brand/50" />
                  <p className="text-lg font-serif font-bold text-coffee-dark mb-2">{t('admin.underConstruction')}</p>
                  <p className="text-sm font-sans max-w-sm mx-auto">
                    {t('admin.functionalList', { module: navItems.find(i => i.id === activeTab)?.label })}
                  </p>
                </div>
              </>
            )}
          </motion.div>

        </div>
      </main>

    </div>
  );
}
